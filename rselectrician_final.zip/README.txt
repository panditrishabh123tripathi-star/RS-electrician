RS Electrician — Booking-only site (EmailJS)
-------------------------------------------

Files:
- index.html  : Booking form integrated with EmailJS (already set to your EmailJS IDs)
- style.css   : Styling
- images/logo.png : Logo file

How to use:
1. Unzip and upload the folder contents to GitHub repository (root).
2. Enable GitHub Pages from Settings -> Pages (branch: main, folder: root).
3. Open the site URL; the booking form will send emails via EmailJS.

Notes:
- EmailJS credentials are already in the code (Public Key, Service ID, Template ID).
- Make sure in your EmailJS template the field names match: customer_name, phone_number, email, service_type, booking_date, address, message
- If emails aren't arriving, check Spam or EmailJS dashboard for logs.
