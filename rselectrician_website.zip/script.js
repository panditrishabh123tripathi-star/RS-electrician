document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    fetch('https://formsubmit.co/ajax/rselectrician9283@gmail.com', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('responseMessage').innerText = "✅ Booking successful! We'll contact you soon.";
        document.getElementById('bookingForm').reset();
    })
    .catch(error => {
        document.getElementById('responseMessage').innerText = "❌ Booking failed. Please try again.";
    });
});